package com.travel.daily.traveldaily;

import android.support.v4.app.FragmentActivity;

/**
 * Created on 16/5/19.
 */

public class BaseActivity extends FragmentActivity {

}
