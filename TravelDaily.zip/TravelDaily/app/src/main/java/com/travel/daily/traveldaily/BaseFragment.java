package com.travel.daily.traveldaily;

import android.support.v4.app.Fragment;

/**
 * Created on 16/5/19.
 */

public class BaseFragment extends Fragment {
}
